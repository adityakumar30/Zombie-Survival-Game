#pragma once
#include <SFML/Audio.hpp>
#include <map>
#include <string>
#include <memory>

class SoundManager {
public:
    static SoundManager& instance();

    void loadSound(const std::string& name, const std::string& path);
    void playSound(const std::string& name, float volume = 100.f);

    void playMusic(const std::string& path, bool loop = true, float volume = 50.f);
    void stopMusic();
    void pauseMusic();
    void resumeMusic();
    bool isMusicPlaying() const;

private:
    SoundManager() = default;

    std::map<std::string, sf::SoundBuffer>            m_buffers;
    std::map<std::string, std::unique_ptr<sf::Sound>> m_sounds;

    sf::Music   m_music;
    std::string m_currentMusicPath;
};
