#pragma once
#include <SFML/Graphics.hpp>
#include <vector>
#include <memory>
#include "Zombie.h"

class BossZombie {
public:
    BossZombie(sf::Vector2f position);

    // Returns newly spawned minions (may be empty)
    std::vector<std::unique_ptr<Zombie>> update(float dt, sf::Vector2f playerPos);
    void draw(sf::RenderWindow& window) const;

    void  takeDamage(float amount);
    bool  isAlive()    const { return m_hp > 0.f; }
    float getDamage()  const;
    sf::FloatRect getBounds() const;
    sf::Vector2f  getPosition() const { return m_body.getPosition(); }
    float         getRadius()   const { return m_radius; }
    float         getHpPercent() const { return m_hp / m_maxHp; }

private:
    enum class BossState { Chase, Charge, Spawn, Roar };

    void startCharge(sf::Vector2f playerPos);

    sf::CircleShape    m_body;
    sf::RectangleShape m_hpBarBg;
    sf::RectangleShape m_hpBar;

    float m_hp;
    float m_maxHp;
    float m_radius;
    float m_speed;

    BossState m_state;
    sf::Vector2f m_chargeDir;
    float m_chargeCooldown;
    float m_chargeTimer;
    float m_spawnCooldown;
    float m_spawnTimer;
    float m_roarTimer;

    float m_hitFlashTimer;
};
