#pragma once
#include <SFML/Graphics.hpp>
#include <vector>
#include <memory>
#include <string>

#include "Player.h"
#include "Zombie.h"
#include "BossZombie.h"
#include "Bullet.h"
#include "PowerUp.h"
#include "Particle.h"
#include "LevelManager.h"

enum class GameState {
    MainMenu,
    Playing,
    Paused,
    LevelTransition,
    BossIntro,
    GameOver,
    Victory
};

class Game {
public:
    Game();
    void run();

private:
    // Core loop
    void processEvents();
    void update(float dt);
    void render();

    // State-specific updates
    void updatePlaying(float dt);
    void updateBossLevel(float dt);

    // Spawning
    void spawnZombie();
    sf::Vector2f randomEdgePosition() const;

    // Collision
    void handleBulletZombieCollisions();
    void handleBulletBossCollisions();
    void handleZombiePlayerCollisions(float dt);
    void handleBossPlayerCollision(float dt);
    void handlePowerUpCollisions();

    // UI helpers
    void drawHUD();
    void drawMainMenu();
    void drawPauseMenu();
    void drawLevelTransition();
    void drawBossIntro();
    void drawGameOver();
    void drawVictory();
    void drawBossHPBar();

    sf::Text makeText(const std::string& str, unsigned size,
                      sf::Color color, sf::Vector2f pos) const;

    // Misc
    void startLevel();
    void startBossLevel();
    void triggerScreenShake(float magnitude, float duration);
    void applyScreenShake(float dt);
    void trySpawnPowerUp(sf::Vector2f pos);
    void saveHighScore();
    void loadHighScore();

    // Window & view
    sf::RenderWindow m_window;
    sf::View         m_gameView;
    sf::View         m_uiView;

    // Font
    sf::Font m_font;

    // Entities
    std::unique_ptr<Player>                  m_player;
    std::vector<std::unique_ptr<Zombie>>     m_zombies;
    std::unique_ptr<BossZombie>              m_boss;
    std::vector<std::unique_ptr<Bullet>>     m_bullets;
    std::vector<std::unique_ptr<PowerUp>>    m_powerUps;
    ParticleSystem                           m_particles;

    // Managers
    LevelManager m_levelManager;

    // State
    GameState m_state;
    float     m_stateTimer;

    // Level tracking
    int   m_zombiesKilled;
    int   m_zombiesSpawned;
    float m_spawnTimer;
    float m_survivalTimer;

    // Score
    int   m_score;
    int   m_highScore;

    // Screen shake
    float        m_shakeTimer;
    float        m_shakeMagnitude;
    sf::Vector2f m_shakeOffset;

    // Background
    std::unique_ptr<sf::Sprite> m_background;
    std::vector<sf::RectangleShape> m_bgDetails;

    // Menu selection
    int m_menuSelection;
    int m_pauseSelection;
};
