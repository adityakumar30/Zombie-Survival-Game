#pragma once
#include <vector>
#include "Zombie.h"

struct LevelConfig {
    int   level;
    int   zombiesToKill;      // 0 = survival timer mode
    float survivalTime;       // used when zombiesToKill == 0
    float spawnInterval;      // seconds between spawns
    int   maxZombiesOnScreen;
    float normalRatio;        // 0-1 fraction of normal zombies
    float fastRatio;
    float tankRatio;
    float speedMultiplier;    // applied on top of base speeds
    float powerUpChance;      // 0-1 chance per zombie kill
};

class LevelManager {
public:
    LevelManager();

    void        nextLevel();
    void        reset();

    const LevelConfig& current() const { return m_configs[m_currentLevel]; }
    int         getLevelNumber()  const { return m_currentLevel + 1; }
    bool        isBossLevel()     const { return m_currentLevel >= (int)m_configs.size(); }
    bool        isLastLevel()     const { return m_currentLevel == (int)m_configs.size() - 1; }

    ZombieType  pickZombieType()  const;

private:
    void buildConfigs();

    std::vector<LevelConfig> m_configs;
    int m_currentLevel;
};
