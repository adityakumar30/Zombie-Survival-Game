#pragma once
#include <SFML/Graphics.hpp>

class Bullet {
public:
    Bullet(sf::Vector2f position, sf::Vector2f direction, float damage = 25.f);

    void update(float dt);
    void draw(sf::RenderWindow& window) const;

    bool isAlive()  const { return m_alive; }
    void kill()           { m_alive = false; }

    sf::FloatRect getBounds() const;
    sf::Vector2f  getPosition() const { return m_shape.getPosition(); }
    float         getDamage()   const { return m_damage; }

private:
    sf::CircleShape m_shape;
    sf::Vector2f    m_velocity;
    float           m_lifetime;
    float           m_damage;
    bool            m_alive;
};
