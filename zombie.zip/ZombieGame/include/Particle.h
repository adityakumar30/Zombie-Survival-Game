#pragma once
#include <SFML/Graphics.hpp>
#include <vector>

struct Particle {
    sf::CircleShape shape;
    sf::Vector2f    velocity;
    float           lifetime;
    float           maxLifetime;
};

class ParticleSystem {
public:
    void emit(sf::Vector2f position, sf::Color color, int count = 8);
    void update(float dt);
    void draw(sf::RenderWindow& window) const;
    void clear() { m_particles.clear(); }

private:
    std::vector<Particle> m_particles;
};
