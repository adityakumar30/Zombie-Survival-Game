#pragma once

// Window
const int WINDOW_WIDTH  = 1280;
const int WINDOW_HEIGHT = 720;
const char* const WINDOW_TITLE = "Zombie Survival";

// Player
const float PLAYER_SPEED        = 200.f;
const float PLAYER_MAX_HEALTH   = 100.f;
const int   PLAYER_MAX_AMMO     = 30;
const float PLAYER_RELOAD_TIME  = 2.0f;  // seconds
const float PLAYER_FIRE_RATE    = 0.15f; // seconds between shots
const float PLAYER_RADIUS       = 20.f;

// Bullet
const float BULLET_SPEED    = 600.f;
const float BULLET_LIFETIME = 2.0f;
const float BULLET_RADIUS   = 5.f;
const float BULLET_DAMAGE   = 25.f;

// Zombie base stats
const float ZOMBIE_NORMAL_SPEED  = 80.f;
const float ZOMBIE_NORMAL_HP     = 60.f;
const float ZOMBIE_FAST_SPEED    = 160.f;
const float ZOMBIE_FAST_HP       = 30.f;
const float ZOMBIE_TANK_SPEED    = 50.f;
const float ZOMBIE_TANK_HP       = 200.f;
const float ZOMBIE_DAMAGE        = 20.f;   // damage per second while touching player
const float ZOMBIE_RADIUS        = 22.f;

// Boss
const float BOSS_HP              = 1500.f;
const float BOSS_SPEED           = 100.f;
const float BOSS_RADIUS          = 50.f;
const float BOSS_DAMAGE          = 40.f;
const float BOSS_CHARGE_SPEED    = 350.f;
const float BOSS_CHARGE_COOLDOWN = 5.f;
const float BOSS_SPAWN_COOLDOWN  = 8.f;

// Levels
const int   TOTAL_LEVELS         = 10;
const float LEVEL_TRANSITION_TIME = 3.f;

// Power-ups
const float POWERUP_RADIUS       = 15.f;
const float POWERUP_LIFETIME     = 10.f;
const float POWERUP_HEAL_AMOUNT  = 30.f;
const float POWERUP_RAPIDFIRE_DURATION = 5.f;
const float POWERUP_SHIELD_DURATION    = 5.f;

// Screen shake
const float SHAKE_DURATION       = 0.4f;
const float SHAKE_MAGNITUDE      = 8.f;
