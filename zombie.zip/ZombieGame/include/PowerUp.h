#pragma once
#include <SFML/Graphics.hpp>
#include "Player.h"

class PowerUp {
public:
    PowerUp(sf::Vector2f position, PowerUpType type);

    void update(float dt);
    void draw(sf::RenderWindow& window) const;

    bool isAlive() const { return m_alive && m_lifetime > 0.f; }
    void collect() { m_alive = false; }
    PowerUpType getType() const { return m_type; }
    sf::FloatRect getBounds() const;

private:
    sf::CircleShape m_shape;
    sf::Font m_font;
    sf::Text* m_label; // Change this from 'sf::Text m_label' to a pointer

    PowerUpType m_type;
    float m_lifetime;
    bool m_alive;
    float m_bobTimer;
};
