#pragma once
#include <SFML/Graphics.hpp>
#include <map>
#include <string>

// Singleton texture cache
class TextureManager {
public:
    static TextureManager& instance();

    // Returns a reference to a loaded (or cached) texture.
    // If the file cannot be loaded a 32x32 placeholder is returned.
    sf::Texture& get(const std::string& path);

private:
    TextureManager() = default;
    std::map<std::string, sf::Texture> m_cache;

    sf::Texture makePlaceholder(sf::Color color);
};
