#pragma once
#include <SFML/Graphics.hpp>
#include <string>

enum class ZombieType { Normal, Fast, Tank };

class Zombie {
public:
    Zombie(sf::Vector2f position, ZombieType type);

    void update(float dt, sf::Vector2f playerPos);
    void draw(sf::RenderWindow& window) const;

    void        takeDamage(float amount);
    bool        isAlive()   const { return m_hp > 0.f; }
    float       getDamage() const { return m_damage; }
    ZombieType  getType()   const { return m_type; }
    sf::Vector2f getPosition() const { return m_sprite.getPosition(); }
    sf::FloatRect getBounds()  const;
    float        getRadius()   const { return m_radius; }
    int          getScore()    const { return m_scoreValue; }

private:
    void initVisuals();

    sf::Sprite         m_sprite;
    sf::RectangleShape m_hpBarBg;
    sf::RectangleShape m_hpBar;

    ZombieType   m_type;
    float        m_hp;
    float        m_maxHp;
    float        m_speed;
    float        m_damage;
    float        m_radius;
    int          m_scoreValue;

    // Flash on hit
    float        m_hitFlashTimer;
};
