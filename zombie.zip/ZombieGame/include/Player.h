#pragma once
#include <SFML/Graphics.hpp>
#include <vector>
#include <memory>
#include "Bullet.h"

enum class PowerUpType { HealthPack, RapidFire, Shield };

class Player {
public:
    Player(sf::Vector2f startPos);

    void handleInput(float dt);
    void update(float dt);
    void draw(sf::RenderWindow& window) const;

    // Shooting – returns new bullet if fired, nullptr otherwise
    std::unique_ptr<Bullet> tryShoot(sf::Vector2f mouseWorldPos);

    void takeDamage(float amount);
    void heal(float amount);
    void applyPowerUp(PowerUpType type);

    bool  isAlive()       const { return m_hp > 0.f; }
    float getHpPercent()  const { return m_hp / m_maxHp; }
    float getHp()         const { return m_hp; }
    int   getAmmo()       const { return m_ammo; }
    int   getMaxAmmo()    const { return m_maxAmmo; }
    bool  isReloading()   const { return m_reloadTimer > 0.f; }
    float getReloadPct()  const;
    bool  hasShield()     const { return m_shieldTimer > 0.f; }

    sf::Vector2f  getPosition() const { return m_sprite.getPosition(); }
    sf::FloatRect getBounds()   const;
    float         getRadius()   const { return m_radius; }

private:
    void drawHUD(sf::RenderWindow& window) const;

    sf::Sprite         m_sprite;
    sf::CircleShape    m_shieldVisual;

    float m_hp;
    float m_maxHp;
    float m_radius;

    int   m_ammo;
    int   m_maxAmmo;
    float m_reloadTimer;
    float m_fireTimer;

    float m_rapidFireTimer;
    float m_shieldTimer;

    // For rotation toward mouse
    float m_angle;
};
