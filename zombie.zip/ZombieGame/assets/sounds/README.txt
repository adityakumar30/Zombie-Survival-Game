Place the following audio files here (WAV or OGG):
  shoot.wav       - gunshot sound
  hit.wav         - bullet-hit sound
  zombie.wav      - zombie groan
  powerup.wav     - power-up collect
  gameover.wav    - game over sting
  victory.wav     - victory fanfare
  background.ogg  - looping background music
  boss.ogg        - looping boss music

The game runs without these files (no crash), just silently.
Free sound packs: https://freesound.org  |  https://opengameart.org
