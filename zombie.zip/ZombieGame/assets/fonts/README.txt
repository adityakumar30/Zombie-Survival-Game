Place arial.ttf (or any TTF font) here.
The game will fall back to C:/Windows/Fonts/arial.ttf if this file is missing.
