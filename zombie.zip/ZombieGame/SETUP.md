# Zombie Survival – Build & Setup Guide

## Project Structure

```
ZombieGame/
├── CMakeLists.txt          # CMake build (recommended)
├── Makefile                # MinGW direct make
├── SETUP.md                # This file
├── include/
│   ├── Constants.h
│   ├── Game.h
│   ├── Player.h
│   ├── Zombie.h
│   ├── BossZombie.h
│   ├── Bullet.h
│   ├── PowerUp.h
│   ├── Particle.h
│   ├── LevelManager.h
│   ├── TextureManager.h
│   └── SoundManager.h
├── src/
│   ├── main.cpp
│   ├── Game.cpp
│   ├── Player.cpp
│   ├── Zombie.cpp
│   ├── BossZombie.cpp
│   ├── Bullet.cpp
│   ├── PowerUp.cpp
│   ├── Particle.cpp
│   ├── LevelManager.cpp
│   ├── TextureManager.cpp
│   └── SoundManager.cpp
└── assets/
    ├── fonts/              # Place arial.ttf here
    └── sounds/             # Place .wav/.ogg files here (optional)
```

---

## Option A – Visual Studio 2022 (Recommended)

### 1. Install SFML
1. Download **SFML 2.5.1** (Visual C++ 17 – 64-bit) from https://www.sfml-dev.org/download.php
2. Extract to `C:\SFML-2.5.1`

### 2. Install CMake
Download from https://cmake.org/download/ and add to PATH.

### 3. Configure & Build
```bat
cd ZombieGame
cmake -B build -G "Visual Studio 17 2022" -A x64 -DSFML_ROOT=C:/SFML-2.5.1
cmake --build build --config Release
```

### 4. Copy SFML DLLs
Copy all `*.dll` files from `C:\SFML-2.5.1\bin` into `build\Release\`.

### 5. Run
```bat
build\Release\ZombieGame.exe
```

---

## Option B – MinGW-w64 (g++)

### 1. Install MinGW-w64
- Download from https://winlibs.com (GCC 13+, POSIX threads, 64-bit)
- Add `C:\mingw64\bin` to your PATH

### 2. Install SFML for MinGW
1. Download **SFML 2.5.1** (GCC 7.3.0 MinGW – 64-bit) from https://www.sfml-dev.org/download.php
2. Extract to `C:\SFML-2.5.1`

### 3. Build
```bat
cd ZombieGame
make SFML_ROOT=C:/SFML-2.5.1
```

### 4. Copy SFML DLLs
Copy all `*.dll` from `C:\SFML-2.5.1\bin` next to `ZombieGame.exe`.

### 5. Run
```bat
ZombieGame.exe
```

---

## Option C – vcpkg (easiest dependency management)

```bat
git clone https://github.com/microsoft/vcpkg
cd vcpkg && bootstrap-vcpkg.bat
vcpkg install sfml:x64-windows
vcpkg integrate install

cd ZombieGame
cmake -B build -DCMAKE_TOOLCHAIN_FILE=C:/vcpkg/scripts/buildsystems/vcpkg.cmake
cmake --build build --config Release
```

---

## Adding a Font

Copy `arial.ttf` (from `C:\Windows\Fonts\`) into `assets/fonts/`:
```bat
copy C:\Windows\Fonts\arial.ttf ZombieGame\assets\fonts\arial.ttf
```
The game automatically falls back to the system font if the file is missing.

---

## Adding Sounds (Optional)

Place free sound files from https://freesound.org or https://opengameart.org into `assets/sounds/`:

| File             | Description              |
|------------------|--------------------------|
| shoot.wav        | Gunshot                  |
| hit.wav          | Bullet impact            |
| zombie.wav       | Zombie groan             |
| powerup.wav      | Power-up collect         |
| gameover.wav     | Game over sting          |
| victory.wav      | Victory fanfare          |
| background.ogg   | Looping background music |
| boss.ogg         | Looping boss music       |

The game runs silently without these files – no crash.

---

## Controls

| Key / Button     | Action              |
|------------------|---------------------|
| WASD / Arrow Keys| Move player         |
| Left Mouse Button| Shoot               |
| R                | Reload              |
| ESC              | Pause / Resume      |
| Enter            | Confirm menu option |

---

## Gameplay Overview

- **10 levels** of increasing difficulty (more zombies, faster, tankier)
- **3 zombie types**: Normal (green), Fast (yellow), Tank (purple)
- **Boss level (11)**: Zombie King with charge attack, minion spawning, and a large HP bar
- **Power-ups**: Health Pack (red), Rapid Fire (yellow), Shield (blue)
- **Score** saved to `highscore.dat` in the working directory
