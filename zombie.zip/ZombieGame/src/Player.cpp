#include "Player.h"
#include "TextureManager.h"
#include "Constants.h"
#include <cmath>

Player::Player(sf::Vector2f startPos)
    : m_sprite(TextureManager::instance().get("assets/player.png")),
      m_hp(PLAYER_MAX_HEALTH), m_maxHp(PLAYER_MAX_HEALTH),
      m_radius(PLAYER_RADIUS),
      m_ammo(PLAYER_MAX_AMMO), m_maxAmmo(PLAYER_MAX_AMMO),
      m_reloadTimer(0.f), m_fireTimer(0.f),
      m_rapidFireTimer(0.f), m_shieldTimer(0.f), m_angle(0.f)
{
    // Scale sprite so it fits within the player radius circle
    sf::FloatRect bounds = m_sprite.getLocalBounds();
    float diameter = m_radius * 2.f;
    m_sprite.setScale({diameter / bounds.size.x, diameter / bounds.size.y});
    m_sprite.setOrigin({bounds.size.x / 2.f, bounds.size.y / 2.f});
    m_sprite.setPosition(startPos);

    m_shieldVisual.setRadius(m_radius + 8.f);
    m_shieldVisual.setOrigin({m_radius+8.f, m_radius+8.f});
    m_shieldVisual.setFillColor(sf::Color(100,200,255,80));
    m_shieldVisual.setOutlineThickness(2.f);
    m_shieldVisual.setOutlineColor(sf::Color(100,200,255,200));
}

void Player::handleInput(float dt) {
    sf::Vector2f vel(0.f, 0.f);
    if (sf::Keyboard::isKeyPressed(sf::Keyboard::Key::W) ||
        sf::Keyboard::isKeyPressed(sf::Keyboard::Key::Up))    vel.y -= 1.f;
    if (sf::Keyboard::isKeyPressed(sf::Keyboard::Key::S) ||
        sf::Keyboard::isKeyPressed(sf::Keyboard::Key::Down))  vel.y += 1.f;
    if (sf::Keyboard::isKeyPressed(sf::Keyboard::Key::A) ||
        sf::Keyboard::isKeyPressed(sf::Keyboard::Key::Left))  vel.x -= 1.f;
    if (sf::Keyboard::isKeyPressed(sf::Keyboard::Key::D) ||
        sf::Keyboard::isKeyPressed(sf::Keyboard::Key::Right)) vel.x += 1.f;

    float len = std::sqrt(vel.x*vel.x + vel.y*vel.y);
    if (len > 0.f) vel /= len;
    m_sprite.move(vel * PLAYER_SPEED * dt);

    sf::Vector2f pos = m_sprite.getPosition();
    pos.x = std::max(m_radius, std::min(pos.x, (float)WINDOW_WIDTH  - m_radius));
    pos.y = std::max(m_radius, std::min(pos.y, (float)WINDOW_HEIGHT - m_radius));
    m_sprite.setPosition(pos);

    if (sf::Keyboard::isKeyPressed(sf::Keyboard::Key::R) &&
        m_reloadTimer <= 0.f && m_ammo < m_maxAmmo)
        m_reloadTimer = PLAYER_RELOAD_TIME;
}

void Player::update(float dt) {
    if (m_reloadTimer > 0.f) {
        m_reloadTimer -= dt;
        if (m_reloadTimer <= 0.f) { m_reloadTimer = 0.f; m_ammo = m_maxAmmo; }
    }
    if (m_fireTimer      > 0.f) m_fireTimer      -= dt;
    if (m_rapidFireTimer > 0.f) m_rapidFireTimer -= dt;
    if (m_shieldTimer    > 0.f) m_shieldTimer    -= dt;
    m_shieldVisual.setPosition(m_sprite.getPosition());
}

std::unique_ptr<Bullet> Player::tryShoot(sf::Vector2f mouseWorldPos) {
    if (m_reloadTimer > 0.f) return nullptr;
    if (m_ammo <= 0) { m_reloadTimer = PLAYER_RELOAD_TIME; return nullptr; }
    float cooldown = (m_rapidFireTimer > 0.f) ? PLAYER_FIRE_RATE * 0.3f : PLAYER_FIRE_RATE;
    if (m_fireTimer > 0.f) return nullptr;
    m_fireTimer = cooldown;
    --m_ammo;
    sf::Vector2f dir = mouseWorldPos - m_sprite.getPosition();

    // Rotate sprite to face mouse
    float angle = std::atan2(dir.y, dir.x) * 180.f / 3.14159265f;
    m_sprite.setRotation(sf::degrees(angle + 90.f));

    float damage = (m_rapidFireTimer > 0.f) ? BULLET_DAMAGE * 1.5f : BULLET_DAMAGE;
    return std::make_unique<Bullet>(m_sprite.getPosition(), dir, damage);
}

void Player::takeDamage(float amount) {
    if (m_shieldTimer > 0.f) return;
    m_hp -= amount;
    if (m_hp < 0.f) m_hp = 0.f;
}

void Player::heal(float amount) {
    m_hp = std::min(m_hp + amount, m_maxHp);
}

void Player::applyPowerUp(PowerUpType type) {
    switch (type) {
        case PowerUpType::HealthPack: heal(POWERUP_HEAL_AMOUNT);                     break;
        case PowerUpType::RapidFire:  m_rapidFireTimer = POWERUP_RAPIDFIRE_DURATION; break;
        case PowerUpType::Shield:     m_shieldTimer    = POWERUP_SHIELD_DURATION;    break;
    }
}

float Player::getReloadPct() const {
    if (m_reloadTimer <= 0.f) return 1.f;
    return 1.f - (m_reloadTimer / PLAYER_RELOAD_TIME);
}

sf::FloatRect Player::getBounds() const { return m_sprite.getGlobalBounds(); }

void Player::draw(sf::RenderWindow& window) const {
    if (m_shieldTimer > 0.f) window.draw(m_shieldVisual);
    window.draw(m_sprite);
}
