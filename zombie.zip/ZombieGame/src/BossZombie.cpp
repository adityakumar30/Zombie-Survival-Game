#include "BossZombie.h"
#include "Constants.h"
#include <cmath>
#include <cstdlib>

BossZombie::BossZombie(sf::Vector2f position)
    : m_hp(BOSS_HP), m_maxHp(BOSS_HP), m_radius(BOSS_RADIUS),
      m_speed(BOSS_SPEED), m_state(BossState::Chase),
      m_chargeCooldown(BOSS_CHARGE_COOLDOWN), m_chargeTimer(0.f),
      m_spawnCooldown(BOSS_SPAWN_COOLDOWN), m_spawnTimer(0.f),
      m_roarTimer(0.f), m_hitFlashTimer(0.f)
{
    m_body.setRadius(m_radius);
    m_body.setOrigin({m_radius, m_radius});
    m_body.setFillColor(sf::Color(180,0,0));
    m_body.setOutlineThickness(4.f);
    m_body.setOutlineColor(sf::Color(255,100,0));
    m_body.setPosition(position);

    m_hpBarBg.setSize({300.f, 20.f});
    m_hpBarBg.setFillColor(sf::Color(60,0,0));
    m_hpBarBg.setPosition({490.f, 20.f});

    m_hpBar.setSize({300.f, 20.f});
    m_hpBar.setFillColor(sf::Color(220,0,0));
    m_hpBar.setPosition({490.f, 20.f});
}

std::vector<std::unique_ptr<Zombie>> BossZombie::update(float dt, sf::Vector2f playerPos) {
    std::vector<std::unique_ptr<Zombie>> spawned;
    if (!isAlive()) return spawned;

    if (m_hitFlashTimer > 0.f) {
        m_hitFlashTimer -= dt;
        m_body.setFillColor(sf::Color::White);
    } else {
        m_body.setFillColor(sf::Color(180,0,0));
    }

    m_chargeCooldown -= dt;
    m_spawnCooldown  -= dt;

    switch (m_state) {
        case BossState::Chase: {
            sf::Vector2f dir = playerPos - m_body.getPosition();
            float len = std::sqrt(dir.x*dir.x + dir.y*dir.y);
            if (len > 0.f) dir /= len;
            m_body.move(dir * m_speed * dt);
            if (m_chargeCooldown <= 0.f) startCharge(playerPos);
            if (m_spawnCooldown  <= 0.f) {
                m_state = BossState::Spawn;
                m_spawnTimer = 1.5f;
                m_spawnCooldown = BOSS_SPAWN_COOLDOWN;
            }
            break;
        }
        case BossState::Charge:
            m_chargeTimer -= dt;
            m_body.move(m_chargeDir * BOSS_CHARGE_SPEED * dt);
            if (m_chargeTimer <= 0.f) {
                m_state = BossState::Chase;
                m_chargeCooldown = BOSS_CHARGE_COOLDOWN;
            }
            break;
        case BossState::Spawn:
            m_spawnTimer -= dt;
            if (m_spawnTimer <= 0.f) {
                for (int i = 0; i < 3; ++i) {
                    float angle = (float)(rand() % 360) * 3.14159f / 180.f;
                    sf::Vector2f offset(std::cos(angle)*80.f, std::sin(angle)*80.f);
                    spawned.push_back(std::make_unique<Zombie>(
                        m_body.getPosition() + offset, ZombieType::Normal));
                }
                m_state = BossState::Chase;
            }
            break;
        case BossState::Roar:
            m_roarTimer -= dt;
            if (m_roarTimer <= 0.f) m_state = BossState::Chase;
            break;
    }

    float pct = m_hp / m_maxHp;
    m_hpBar.setSize({300.f * pct, 20.f});
    return spawned;
}

void BossZombie::startCharge(sf::Vector2f playerPos) {
    m_state = BossState::Charge;
    sf::Vector2f dir = playerPos - m_body.getPosition();
    float len = std::sqrt(dir.x*dir.x + dir.y*dir.y);
    if (len > 0.f) dir /= len;
    m_chargeDir   = dir;
    m_chargeTimer = 0.6f;
}

void BossZombie::draw(sf::RenderWindow& window) const {
    if (!isAlive()) return;
    window.draw(m_body);
}

void BossZombie::takeDamage(float amount) {
    m_hp -= amount;
    if (m_hp < 0.f) m_hp = 0.f;
    m_hitFlashTimer = 0.1f;
}

float BossZombie::getDamage() const {
    return (m_state == BossState::Charge) ? BOSS_DAMAGE * 2.f : BOSS_DAMAGE;
}

sf::FloatRect BossZombie::getBounds() const {
    return m_body.getGlobalBounds();
}
