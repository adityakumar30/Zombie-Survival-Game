#include "Zombie.h"
#include "TextureManager.h"
#include "Constants.h"
#include <cmath>

Zombie::Zombie(sf::Vector2f position, ZombieType type)
    : m_sprite(TextureManager::instance().get("assets/zombie.png")),
      m_type(type),
      m_hp(0.f), m_maxHp(0.f), m_speed(0.f), m_damage(0.f),
      m_radius(0.f), m_scoreValue(0),
      m_hitFlashTimer(0.f)
{
    switch (type) {
        case ZombieType::Normal:
            m_hp = m_maxHp = ZOMBIE_NORMAL_HP; m_speed = ZOMBIE_NORMAL_SPEED;
            m_radius = ZOMBIE_RADIUS;           m_damage = ZOMBIE_DAMAGE;
            m_scoreValue = 10; break;
        case ZombieType::Fast:
            m_hp = m_maxHp = ZOMBIE_FAST_HP;   m_speed = ZOMBIE_FAST_SPEED;
            m_radius = ZOMBIE_RADIUS * 0.8f;    m_damage = ZOMBIE_DAMAGE * 0.7f;
            m_scoreValue = 20; break;
        case ZombieType::Tank:
            m_hp = m_maxHp = ZOMBIE_TANK_HP;   m_speed = ZOMBIE_TANK_SPEED;
            m_radius = ZOMBIE_RADIUS * 1.4f;    m_damage = ZOMBIE_DAMAGE * 1.5f;
            m_scoreValue = 30; break;
    }
    initVisuals();
    m_sprite.setPosition(position);
}

void Zombie::initVisuals() {
    // Scale sprite to fit the zombie's radius
    sf::FloatRect bounds = m_sprite.getLocalBounds();
    float diameter = m_radius * 2.f;
    m_sprite.setScale({diameter / bounds.size.x, diameter / bounds.size.y});
    m_sprite.setOrigin({bounds.size.x / 2.f, bounds.size.y / 2.f});

    // Tint by type so they remain visually distinct
    switch (m_type) {
        case ZombieType::Normal: m_sprite.setColor(sf::Color(255, 255, 255));    break; // default
        case ZombieType::Fast:   m_sprite.setColor(sf::Color(255, 255, 100));    break; // yellow tint
        case ZombieType::Tank:   m_sprite.setColor(sf::Color(180, 100, 255));    break; // purple tint
    }

    m_hpBarBg.setSize({m_radius*2.f, 5.f});
    m_hpBarBg.setFillColor(sf::Color(80,0,0));
    m_hpBarBg.setOrigin({m_radius, 0.f});

    m_hpBar.setSize({m_radius*2.f, 5.f});
    m_hpBar.setFillColor(sf::Color::Red);
    m_hpBar.setOrigin({m_radius, 0.f});
}

void Zombie::update(float dt, sf::Vector2f playerPos) {
    if (!isAlive()) return;

    sf::Vector2f dir = playerPos - m_sprite.getPosition();
    float len = std::sqrt(dir.x*dir.x + dir.y*dir.y);
    if (len > 0.f) dir /= len;
    m_sprite.move(dir * m_speed * dt);

    // Rotate sprite to face the player
    float angle = std::atan2(dir.y, dir.x) * 180.f / 3.14159265f;
    m_sprite.setRotation(sf::degrees(angle + 90.f));

    if (m_hitFlashTimer > 0.f) {
        m_hitFlashTimer -= dt;
        m_sprite.setColor(sf::Color(255, 80, 80)); // red flash on hit
    } else {
        switch (m_type) {
            case ZombieType::Normal: m_sprite.setColor(sf::Color(255, 255, 255)); break;
            case ZombieType::Fast:   m_sprite.setColor(sf::Color(255, 255, 100)); break;
            case ZombieType::Tank:   m_sprite.setColor(sf::Color(180, 100, 255)); break;
        }
    }

    sf::Vector2f pos = m_sprite.getPosition();
    m_hpBarBg.setPosition({pos.x, pos.y - m_radius - 8.f});
    m_hpBar.setPosition({pos.x, pos.y - m_radius - 8.f});
    m_hpBar.setSize({m_radius*2.f*(m_hp/m_maxHp), 5.f});
}

void Zombie::draw(sf::RenderWindow& window) const {
    if (!isAlive()) return;
    window.draw(m_sprite);
    window.draw(m_hpBarBg);
    window.draw(m_hpBar);
}

void Zombie::takeDamage(float amount) {
    m_hp -= amount;
    m_hitFlashTimer = 0.1f;
}

sf::FloatRect Zombie::getBounds() const {
    return m_sprite.getGlobalBounds();
}
