#include "LevelManager.h"
#include <cstdlib>

LevelManager::LevelManager() : m_currentLevel(0) {
    buildConfigs();
}

void LevelManager::buildConfigs() {
    // 10 regular levels + boss (handled separately)
    m_configs = {
        // lvl, kills, survTime, spawnInt, maxOnScreen, normal, fast, tank, speedMult, puChance
        {  1,  10,  0.f, 3.0f,  5, 1.0f, 0.0f, 0.0f, 1.0f, 0.10f },
        {  2,  15,  0.f, 2.5f,  6, 0.9f, 0.1f, 0.0f, 1.1f, 0.12f },
        {  3,  20,  0.f, 2.2f,  7, 0.8f, 0.2f, 0.0f, 1.2f, 0.13f },
        {  4,  25,  0.f, 2.0f,  8, 0.7f, 0.2f, 0.1f, 1.3f, 0.14f },
        {  5,  30,  0.f, 1.8f,  9, 0.6f, 0.3f, 0.1f, 1.4f, 0.15f },
        {  6,  35,  0.f, 1.6f, 10, 0.5f, 0.3f, 0.2f, 1.5f, 0.16f },
        {  7,  40,  0.f, 1.4f, 11, 0.4f, 0.4f, 0.2f, 1.6f, 0.17f },
        {  8,  50,  0.f, 1.2f, 12, 0.3f, 0.4f, 0.3f, 1.7f, 0.18f },
        {  9,  60,  0.f, 1.0f, 13, 0.2f, 0.5f, 0.3f, 1.8f, 0.20f },
        { 10,  75,  0.f, 0.8f, 15, 0.2f, 0.4f, 0.4f, 2.0f, 0.22f },
    };
}

void LevelManager::nextLevel() {
    ++m_currentLevel;
}

void LevelManager::reset() {
    m_currentLevel = 0;
}

ZombieType LevelManager::pickZombieType() const {
    const LevelConfig& cfg = current();
    float r = (float)(rand() % 100) / 100.f;
    if (r < cfg.normalRatio) return ZombieType::Normal;
    r -= cfg.normalRatio;
    if (r < cfg.fastRatio)   return ZombieType::Fast;
    return ZombieType::Tank;
}
