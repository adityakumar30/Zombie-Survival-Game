#include "PowerUp.h"
#include "Constants.h"
#include <cmath>

PowerUp::PowerUp(sf::Vector2f position, PowerUpType type)
    : m_type(type),
      m_lifetime(POWERUP_LIFETIME),
      m_alive(true),
      m_bobTimer(0.f),
      m_shape(POWERUP_RADIUS)
{
    // Shape setup
    m_shape.setRadius(POWERUP_RADIUS);

    m_shape.setOutlineThickness(2.f);

    switch (type) {
        case PowerUpType::HealthPack:
            m_shape.setFillColor(sf::Color(255,50,50));
            break;
        case PowerUpType::RapidFire:
            m_shape.setFillColor(sf::Color(255,200,0));
            break;
        case PowerUpType::Shield:
            m_shape.setFillColor(sf::Color(50,150,255));
            break;
    }

    m_shape.setOutlineColor(sf::Color::White);
    m_shape.setPosition(position);
}

void PowerUp::update(float dt) {
    if (!m_alive) return;

    m_lifetime -= dt;
    if (m_lifetime <= 0.f) {
        m_alive = false;
        return;
    }

    m_bobTimer += dt * 3.f;

    sf::Vector2f pos = m_shape.getPosition();
    pos.y += std::sin(m_bobTimer) * 0.5f;

    m_shape.setPosition(pos);

    if (m_lifetime < 3.f) {
        uint8_t alpha = (std::sin(m_lifetime * 10.f) > 0.f) ? 255 : 100;

        sf::Color c = m_shape.getFillColor();
        c.a = alpha;
        m_shape.setFillColor(c);
    }
}

void PowerUp::draw(sf::RenderWindow& window) const {
    if (!m_alive) return;

    window.draw(m_shape);
}

sf::FloatRect PowerUp::getBounds() const {
    return m_shape.getGlobalBounds();
}