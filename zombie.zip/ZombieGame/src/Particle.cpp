#include "Particle.h"
#include <cstdlib>
#include <cmath>
#include <algorithm>

void ParticleSystem::emit(sf::Vector2f position, sf::Color color, int count) {
    for (int i = 0; i < count; ++i) {
        Particle p;
        float angle = (float)(rand() % 360) * 3.14159f / 180.f;
        float speed = 50.f + (float)(rand() % 150);
        p.velocity = {std::cos(angle)*speed, std::sin(angle)*speed};
        p.lifetime = p.maxLifetime = 0.4f + (float)(rand() % 40) / 100.f;
        p.shape.setRadius(3.f);
        p.shape.setOrigin({3.f, 3.f});
        p.shape.setFillColor(color);
        p.shape.setPosition(position);
        m_particles.push_back(std::move(p));
    }
}

void ParticleSystem::update(float dt) {
    for (auto& p : m_particles) {
        p.lifetime -= dt;
        p.shape.move(p.velocity * dt);
        p.velocity *= 0.95f;
        float alpha = (p.lifetime / p.maxLifetime) * 255.f;
        sf::Color c = p.shape.getFillColor();
        c.a = (uint8_t)std::max(0.f, alpha);
        p.shape.setFillColor(c);
    }
    m_particles.erase(
        std::remove_if(m_particles.begin(), m_particles.end(),
            [](const Particle& p){ return p.lifetime <= 0.f; }),
        m_particles.end());
}

void ParticleSystem::draw(sf::RenderWindow& window) const {
    for (const auto& p : m_particles) window.draw(p.shape);
}
