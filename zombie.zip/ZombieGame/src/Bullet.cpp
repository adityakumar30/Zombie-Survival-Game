#include "Bullet.h"
#include "Constants.h"
#include <cmath>

Bullet::Bullet(sf::Vector2f position, sf::Vector2f direction, float damage)
    : m_lifetime(BULLET_LIFETIME), m_damage(damage), m_alive(true)
{
    float len = std::sqrt(direction.x*direction.x + direction.y*direction.y);
    if (len > 0.f) direction /= len;
    m_velocity = direction * BULLET_SPEED;

    m_shape.setRadius(BULLET_RADIUS);
    m_shape.setOrigin({BULLET_RADIUS, BULLET_RADIUS});
    m_shape.setFillColor(sf::Color::Yellow);
    m_shape.setPosition(position);
}

void Bullet::update(float dt) {
    if (!m_alive) return;
    m_shape.move(m_velocity * dt);
    m_lifetime -= dt;
    if (m_lifetime <= 0.f) { m_alive = false; return; }
    auto pos = m_shape.getPosition();
    if (pos.x < -100.f || pos.x > 1400.f || pos.y < -100.f || pos.y > 900.f)
        m_alive = false;
}

void Bullet::draw(sf::RenderWindow& window) const {
    if (m_alive) window.draw(m_shape);
}

sf::FloatRect Bullet::getBounds() const {
    return m_shape.getGlobalBounds();
}
