#include "Game.h"
#include "Constants.h"
#include "SoundManager.h"
#include "TextureManager.h"
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <fstream>
#include <sstream>
#include <algorithm>

// ─── Constructor ─────────────────────────────────────────────────────────────
Game::Game()
    : m_window(sf::VideoMode({(unsigned)WINDOW_WIDTH, (unsigned)WINDOW_HEIGHT}),
               WINDOW_TITLE),
      m_state(GameState::MainMenu),
      m_stateTimer(0.f),
      m_zombiesKilled(0), m_zombiesSpawned(0),
      m_spawnTimer(0.f), m_survivalTimer(0.f),
      m_score(0), m_highScore(0),
      m_shakeTimer(0.f), m_shakeMagnitude(0.f),
      m_menuSelection(0), m_pauseSelection(0)
{
    std::srand((unsigned)std::time(nullptr));
    m_window.setFramerateLimit(60);

    m_gameView = sf::View(sf::FloatRect({0.f,0.f},{(float)WINDOW_WIDTH,(float)WINDOW_HEIGHT}));
    m_uiView   = sf::View(sf::FloatRect({0.f,0.f},{(float)WINDOW_WIDTH,(float)WINDOW_HEIGHT}));

    // Font – try assets folder first, then system
    if (!m_font.openFromFile("assets/fonts/arial.ttf"))
        m_font.openFromFile("C:/Windows/Fonts/arial.ttf");

    // Background – load texture and scale to fill the window
    {
        sf::Texture& bgTex = TextureManager::instance().get("assets/background.png");
        bgTex.setRepeated(false);
        m_background = std::make_unique<sf::Sprite>(bgTex);
        sf::FloatRect lb = m_background->getLocalBounds();
        m_background->setScale({(float)WINDOW_WIDTH  / lb.size.x,
                                 (float)WINDOW_HEIGHT / lb.size.y});
    }

    // No grid lines needed – the background image provides the scene

    loadHighScore();
}

// ─── Main loop ───────────────────────────────────────────────────────────────
void Game::run() {
    sf::Clock clock;
    while (m_window.isOpen()) {
        float dt = clock.restart().asSeconds();
        dt = std::min(dt, 0.05f);
        processEvents();
        update(dt);
        render();
    }
}

// ─── Events (SFML3 variant-based) ────────────────────────────────────────────
void Game::processEvents() {
    while (const std::optional<sf::Event> ev = m_window.pollEvent()) {
        if (ev->is<sf::Event::Closed>()) {
            m_window.close();
            return;
        }

        const auto* kp = ev->getIf<sf::Event::KeyPressed>();
        if (!kp) continue;
        sf::Keyboard::Key key = kp->code;

        switch (m_state) {
            case GameState::MainMenu:
                if (key == sf::Keyboard::Key::Up)
                    m_menuSelection = (m_menuSelection - 1 + 2) % 2;
                if (key == sf::Keyboard::Key::Down)
                    m_menuSelection = (m_menuSelection + 1) % 2;
                if (key == sf::Keyboard::Key::Enter || key == sf::Keyboard::Key::Space) {
                    if (m_menuSelection == 0) {
                        m_levelManager.reset(); m_score = 0; startLevel();
                    } else {
                        m_window.close();
                    }
                }
                break;

            case GameState::Playing:
            case GameState::BossIntro:
                if (key == sf::Keyboard::Key::Escape) {
                    m_state = GameState::Paused;
                    m_pauseSelection = 0;
                    SoundManager::instance().pauseMusic();
                }
                break;

            case GameState::Paused:
                if (key == sf::Keyboard::Key::Up)
                    m_pauseSelection = (m_pauseSelection - 1 + 3) % 3;
                if (key == sf::Keyboard::Key::Down)
                    m_pauseSelection = (m_pauseSelection + 1) % 3;
                if (key == sf::Keyboard::Key::Enter || key == sf::Keyboard::Key::Space) {
                    if (m_pauseSelection == 0) {
                        m_state = GameState::Playing;
                        SoundManager::instance().resumeMusic();
                    }
                    else if (m_pauseSelection == 1) {
                        m_levelManager.reset(); m_score = 0;
                        m_state = GameState::MainMenu;
                        SoundManager::instance().stopMusic();
                    }
                    else {
                        m_window.close();
                    }
                }
                if (key == sf::Keyboard::Key::Escape) {
                    m_state = GameState::Playing;
                    SoundManager::instance().resumeMusic();
                }
                break;

            case GameState::GameOver:
            case GameState::Victory:
                if (key == sf::Keyboard::Key::Enter || key == sf::Keyboard::Key::Space) {
                    m_levelManager.reset(); m_score = 0; m_state = GameState::MainMenu;
                }
                if (key == sf::Keyboard::Key::Escape) m_window.close();
                break;

            case GameState::LevelTransition:
                if (key == sf::Keyboard::Key::Enter) m_stateTimer = 0.f;
                break;

            default: break;
        }
    }
}

// ─── Update ──────────────────────────────────────────────────────────────────
void Game::update(float dt) {
    applyScreenShake(dt);

    switch (m_state) {
        case GameState::Playing:
            updatePlaying(dt);
            break;
        case GameState::BossIntro:
            m_stateTimer -= dt;
            if (m_stateTimer <= 0.f) m_state = GameState::Playing;
            break;
        case GameState::LevelTransition:
            m_stateTimer -= dt;
            if (m_stateTimer <= 0.f) {
                m_levelManager.nextLevel();
                if (m_levelManager.isBossLevel()) startBossLevel();
                else                              startLevel();
            }
            break;
        default: break;
    }
}

void Game::updatePlaying(float dt) {
    if (!m_player || !m_player->isAlive()) {
        saveHighScore();
        SoundManager::instance().stopMusic();
        m_state = GameState::GameOver;
        return;
    }

    m_player->handleInput(dt);
    m_player->update(dt);

    // Shoot
    if (sf::Mouse::isButtonPressed(sf::Mouse::Button::Left)) {
        sf::Vector2i mp = sf::Mouse::getPosition(m_window);
        sf::Vector2f mw = m_window.mapPixelToCoords(mp, m_gameView);
        auto bullet = m_player->tryShoot(mw);
        if (bullet) m_bullets.push_back(std::move(bullet));
    }

    // Bullets
    for (auto& b : m_bullets) b->update(dt);
    m_bullets.erase(std::remove_if(m_bullets.begin(), m_bullets.end(),
        [](const std::unique_ptr<Bullet>& b){ return !b->isAlive(); }), m_bullets.end());

    // Boss path
    if (m_boss) { updateBossLevel(dt); return; }

    // Spawn
    m_spawnTimer -= dt;
    const LevelConfig& cfg = m_levelManager.current();
    if (m_spawnTimer <= 0.f && (int)m_zombies.size() < cfg.maxZombiesOnScreen) {
        spawnZombie();
        m_spawnTimer = cfg.spawnInterval;
    }

    for (auto& z : m_zombies) z->update(dt, m_player->getPosition());

    handleBulletZombieCollisions();
    handleZombiePlayerCollisions(dt);
    handlePowerUpCollisions();

    for (auto& z : m_zombies) {
        if (!z->isAlive()) {
            m_score += z->getScore();
            m_zombiesKilled++;
            m_particles.emit(z->getPosition(), sf::Color::Green, 10);
            trySpawnPowerUp(z->getPosition());
        }
    }
    m_zombies.erase(std::remove_if(m_zombies.begin(), m_zombies.end(),
        [](const std::unique_ptr<Zombie>& z){ return !z->isAlive(); }), m_zombies.end());

    for (auto& p : m_powerUps) p->update(dt);
    m_powerUps.erase(std::remove_if(m_powerUps.begin(), m_powerUps.end(),
        [](const std::unique_ptr<PowerUp>& p){ return !p->isAlive(); }), m_powerUps.end());
    m_particles.update(dt);

    if (m_zombiesKilled >= cfg.zombiesToKill) {
        m_state = GameState::LevelTransition;
        m_stateTimer = LEVEL_TRANSITION_TIME;
    }
}

void Game::updateBossLevel(float dt) {
    if (!m_boss) return;

    auto newMinions = m_boss->update(dt, m_player->getPosition());
    for (auto& m : newMinions) m_zombies.push_back(std::move(m));

    for (auto& z : m_zombies) z->update(dt, m_player->getPosition());

    handleBulletBossCollisions();
    handleBulletZombieCollisions();
    handleBossPlayerCollision(dt);
    handleZombiePlayerCollisions(dt);
    handlePowerUpCollisions();

    for (auto& z : m_zombies) {
        if (!z->isAlive()) {
            m_score += z->getScore();
            m_particles.emit(z->getPosition(), sf::Color::Green, 8);
        }
    }
    m_zombies.erase(std::remove_if(m_zombies.begin(), m_zombies.end(),
        [](const std::unique_ptr<Zombie>& z){ return !z->isAlive(); }), m_zombies.end());

    for (auto& p : m_powerUps) p->update(dt);
    m_powerUps.erase(std::remove_if(m_powerUps.begin(), m_powerUps.end(),
        [](const std::unique_ptr<PowerUp>& p){ return !p->isAlive(); }), m_powerUps.end());
    m_particles.update(dt);

    if (!m_boss->isAlive()) {
        m_score += 500;
        m_particles.emit(m_boss->getPosition(), sf::Color::Red, 30);
        triggerScreenShake(SHAKE_MAGNITUDE * 3.f, SHAKE_DURATION * 2.f);
        saveHighScore();
        SoundManager::instance().stopMusic();
        m_state = GameState::Victory;
    }
}

// ─── Spawning ────────────────────────────────────────────────────────────────
void Game::spawnZombie() {
    ZombieType type = m_levelManager.pickZombieType();
    m_zombies.push_back(std::make_unique<Zombie>(randomEdgePosition(), type));
    ++m_zombiesSpawned;
}

sf::Vector2f Game::randomEdgePosition() const {
    int edge = rand() % 4;
    float x, y;
    switch (edge) {
        case 0: x = (float)(rand() % WINDOW_WIDTH);  y = -30.f;                       break;
        case 1: x = (float)(rand() % WINDOW_WIDTH);  y = WINDOW_HEIGHT + 30.f;        break;
        case 2: x = -30.f;                            y = (float)(rand() % WINDOW_HEIGHT); break;
        default:x = WINDOW_WIDTH + 30.f;              y = (float)(rand() % WINDOW_HEIGHT); break;
    }
    return {x, y};
}

// ─── Collisions ──────────────────────────────────────────────────────────────
void Game::handleBulletZombieCollisions() {
    for (auto& b : m_bullets) {
        if (!b->isAlive()) continue;
        for (auto& z : m_zombies) {
            if (!z->isAlive()) continue;
            if (b->getBounds().findIntersection(z->getBounds())) {
                z->takeDamage(b->getDamage());
                b->kill();
                m_particles.emit(b->getPosition(), sf::Color::Red, 6);
                break;
            }
        }
    }
}

void Game::handleBulletBossCollisions() {
    if (!m_boss || !m_boss->isAlive()) return;
    for (auto& b : m_bullets) {
        if (!b->isAlive()) continue;
        if (b->getBounds().findIntersection(m_boss->getBounds())) {
            m_boss->takeDamage(b->getDamage());
            b->kill();
            m_particles.emit(b->getPosition(), sf::Color(255, 100, 0), 8);
            triggerScreenShake(SHAKE_MAGNITUDE * 0.5f, SHAKE_DURATION * 0.3f);
        }
    }
}

void Game::handleZombiePlayerCollisions(float dt) {
    if (!m_player) return;
    for (auto& z : m_zombies) {
        if (!z->isAlive()) continue;
        if (z->getBounds().findIntersection(m_player->getBounds()))
            m_player->takeDamage(z->getDamage() * dt);
    }
}

void Game::handleBossPlayerCollision(float dt) {
    if (!m_boss || !m_player) return;
    if (m_boss->getBounds().findIntersection(m_player->getBounds())) {
        m_player->takeDamage(m_boss->getDamage() * dt);
        triggerScreenShake(SHAKE_MAGNITUDE, SHAKE_DURATION * 0.5f);
    }
}

void Game::handlePowerUpCollisions() {
    if (!m_player) return;
    for (auto& p : m_powerUps) {
        if (!p->isAlive()) continue;
        if (p->getBounds().findIntersection(m_player->getBounds())) {
            m_player->applyPowerUp(p->getType());
            p->collect();
        }
    }
}

// ─── Level management ────────────────────────────────────────────────────────
void Game::startLevel() {
    m_zombies.clear(); m_bullets.clear(); m_powerUps.clear(); m_particles.clear();
    m_zombiesKilled = 0; m_zombiesSpawned = 0;
    m_spawnTimer = 0.f; m_survivalTimer = 0.f;
    m_player = std::make_unique<Player>(sf::Vector2f((float)WINDOW_WIDTH/2.f, (float)WINDOW_HEIGHT/2.f));
    m_boss.reset();
    m_state = GameState::Playing;
    SoundManager::instance().playMusic("assets/music.ogg", true, 50.f);
}

void Game::startBossLevel() {
    m_zombies.clear(); m_bullets.clear(); m_powerUps.clear(); m_particles.clear();
    if (!m_player)
        m_player = std::make_unique<Player>(sf::Vector2f((float)WINDOW_WIDTH/2.f, (float)WINDOW_HEIGHT/2.f));
    m_boss = std::make_unique<BossZombie>(sf::Vector2f((float)WINDOW_WIDTH/2.f, 100.f));
    m_state = GameState::BossIntro;
    m_stateTimer = 3.f;
    SoundManager::instance().playMusic("assets/music.ogg", true, 70.f); // louder for boss
}

// ─── Screen shake ────────────────────────────────────────────────────────────
void Game::triggerScreenShake(float magnitude, float duration) {
    m_shakeMagnitude = magnitude; m_shakeTimer = duration;
}

void Game::applyScreenShake(float dt) {
    if (m_shakeTimer > 0.f) {
        m_shakeTimer -= dt;
        float x = ((float)(rand() % 200) / 100.f - 1.f) * m_shakeMagnitude;
        float y = ((float)(rand() % 200) / 100.f - 1.f) * m_shakeMagnitude;
        m_shakeOffset = {x, y};
    } else {
        m_shakeOffset = {0.f, 0.f};
    }
    m_gameView.setCenter({(float)WINDOW_WIDTH/2.f + m_shakeOffset.x,
                          (float)WINDOW_HEIGHT/2.f + m_shakeOffset.y});
}

// ─── Power-up spawning ───────────────────────────────────────────────────────
void Game::trySpawnPowerUp(sf::Vector2f pos) {
    const LevelConfig& cfg = m_levelManager.current();
    if ((float)(rand() % 100) / 100.f > cfg.powerUpChance) return;
    int t = rand() % 3;
    PowerUpType type = (t == 0) ? PowerUpType::HealthPack
                     : (t == 1) ? PowerUpType::RapidFire : PowerUpType::Shield;
    m_powerUps.push_back(std::make_unique<PowerUp>(pos, type));
}

// ─── High score ──────────────────────────────────────────────────────────────
void Game::saveHighScore() {
    if (m_score > m_highScore) {
        m_highScore = m_score;
        std::ofstream f("highscore.dat");
        if (f) f << m_highScore;
    }
}

void Game::loadHighScore() {
    std::ifstream f("highscore.dat");
    if (f) f >> m_highScore;
}

// ─── Text helper ─────────────────────────────────────────────────────────────
sf::Text Game::makeText(const std::string& str, unsigned size,
                        sf::Color color, sf::Vector2f pos) const {
    sf::Text t(m_font, str, size);
    t.setFillColor(color);
    t.setPosition(pos);
    return t;
}

// ─── Render ──────────────────────────────────────────────────────────────────
void Game::render() {
    m_window.clear(sf::Color::Black);

    switch (m_state) {
        case GameState::MainMenu:
            m_window.setView(m_uiView);
            drawMainMenu();
            break;

        case GameState::Playing:
        case GameState::BossIntro:
            m_window.setView(m_gameView);
            if (m_background) m_window.draw(*m_background);
            for (auto& p : m_powerUps)  p->draw(m_window);
            m_particles.draw(m_window);
            for (auto& z : m_zombies)   z->draw(m_window);
            if (m_boss) m_boss->draw(m_window);
            for (auto& b : m_bullets)   b->draw(m_window);
            if (m_player) m_player->draw(m_window);
            m_window.setView(m_uiView);
            drawHUD();
            if (m_boss) drawBossHPBar();
            if (m_state == GameState::BossIntro) drawBossIntro();
            break;

        case GameState::Paused:
            m_window.setView(m_gameView);
            if (m_background) m_window.draw(*m_background);
            for (auto& z : m_zombies)   z->draw(m_window);
            if (m_player) m_player->draw(m_window);
            m_window.setView(m_uiView);
            drawHUD();
            drawPauseMenu();
            break;

        case GameState::LevelTransition:
            m_window.setView(m_uiView);
            drawLevelTransition();
            break;

        case GameState::GameOver:
            m_window.setView(m_uiView);
            drawGameOver();
            break;

        case GameState::Victory:
            m_window.setView(m_uiView);
            drawVictory();
            break;
    }

    m_window.display();
}

// ─── HUD ─────────────────────────────────────────────────────────────────────
void Game::drawHUD() {
    if (!m_player) return;

    // HP bar
    sf::RectangleShape hpBg({200.f, 18.f});
    hpBg.setFillColor(sf::Color(80, 0, 0));
    hpBg.setPosition({10.f, 10.f});
    m_window.draw(hpBg);

    sf::RectangleShape hpBar({200.f * m_player->getHpPercent(), 18.f});
    hpBar.setFillColor(sf::Color(220, 30, 30));
    hpBar.setPosition({10.f, 10.f});
    m_window.draw(hpBar);
    m_window.draw(makeText("HP", 13, sf::Color::White, {14.f, 11.f}));

    // Ammo
    std::string ammoStr = m_player->isReloading()
        ? "RELOADING... " + std::to_string((int)(m_player->getReloadPct()*100)) + "%"
        : "AMMO: " + std::to_string(m_player->getAmmo()) + "/" + std::to_string(m_player->getMaxAmmo());
    m_window.draw(makeText(ammoStr, 15, sf::Color::Yellow, {10.f, 32.f}));

    // Score
    m_window.draw(makeText("SCORE: " + std::to_string(m_score), 17, sf::Color::White, {10.f, 52.f}));

    // Level
    std::string lvlStr = m_boss ? "BOSS LEVEL" : "LEVEL " + std::to_string(m_levelManager.getLevelNumber());
    m_window.draw(makeText(lvlStr, 17, sf::Color::Cyan, {(float)WINDOW_WIDTH/2.f - 60.f, 10.f}));

    // Kill progress
    if (!m_boss) {
        const LevelConfig& cfg = m_levelManager.current();
        std::string prog = "KILLS: " + std::to_string(m_zombiesKilled) + "/" + std::to_string(cfg.zombiesToKill);
        m_window.draw(makeText(prog, 15, sf::Color(200,200,200), {(float)WINDOW_WIDTH/2.f - 55.f, 32.f}));
    }

    // High score
    m_window.draw(makeText("BEST: " + std::to_string(m_highScore), 15,
                            sf::Color(180,180,0), {(float)WINDOW_WIDTH - 160.f, 10.f}));

    // Controls hint
    m_window.draw(makeText("WASD:Move  LMB:Shoot  R:Reload  ESC:Pause",
                            12, sf::Color(100,100,100), {10.f, (float)WINDOW_HEIGHT - 20.f}));
}

void Game::drawBossHPBar() {
    if (!m_boss) return;
    sf::RectangleShape bg({304.f, 24.f});
    bg.setFillColor(sf::Color(60,0,0));
    bg.setPosition({488.f, 18.f});
    m_window.draw(bg);

    sf::RectangleShape bar({300.f * m_boss->getHpPercent(), 20.f});
    bar.setFillColor(sf::Color(220,0,0));
    bar.setPosition({490.f, 20.f});
    m_window.draw(bar);
    m_window.draw(makeText("BOSS", 13, sf::Color::White, {492.f, 21.f}));
}

void Game::drawMainMenu() {
    if (m_background) m_window.draw(*m_background);
    m_window.draw(makeText("ZOMBIE SURVIVAL", 58, sf::Color(220,30,30),
                            {(float)WINDOW_WIDTH/2.f - 240.f, 160.f}));
    m_window.draw(makeText("10 Levels + Boss Fight", 22, sf::Color(180,180,180),
                            {(float)WINDOW_WIDTH/2.f - 130.f, 250.f}));
    m_window.draw(makeText("High Score: " + std::to_string(m_highScore), 20,
                            sf::Color::Yellow, {(float)WINDOW_WIDTH/2.f - 90.f, 290.f}));

    const char* opts[] = {"START GAME", "EXIT"};
    for (int i = 0; i < 2; ++i) {
        sf::Color c = (i == m_menuSelection) ? sf::Color::Yellow : sf::Color::White;
        if (i == m_menuSelection) {
            sf::RectangleShape sel({220.f, 40.f});
            sel.setFillColor(sf::Color(80,80,0,120));
            sel.setPosition({(float)WINDOW_WIDTH/2.f - 110.f, 368.f + i*60.f});
            m_window.draw(sel);
        }
        m_window.draw(makeText(opts[i], 32, c, {(float)WINDOW_WIDTH/2.f - 100.f, 370.f + i*60.f}));
    }
    m_window.draw(makeText("Arrow Keys: Navigate   Enter: Select", 16,
                            sf::Color(120,120,120), {(float)WINDOW_WIDTH/2.f - 160.f, 510.f}));
}

void Game::drawPauseMenu() {
    sf::RectangleShape overlay({(float)WINDOW_WIDTH, (float)WINDOW_HEIGHT});
    overlay.setFillColor(sf::Color(0,0,0,160));
    m_window.draw(overlay);
    m_window.draw(makeText("PAUSED", 50, sf::Color::White, {(float)WINDOW_WIDTH/2.f - 90.f, 200.f}));
    const char* opts[] = {"RESUME", "MAIN MENU", "EXIT"};
    for (int i = 0; i < 3; ++i) {
        sf::Color c = (i == m_pauseSelection) ? sf::Color::Yellow : sf::Color::White;
        m_window.draw(makeText(opts[i], 30, c, {(float)WINDOW_WIDTH/2.f - 80.f, 300.f + i*55.f}));
    }
}

void Game::drawLevelTransition() {
    if (m_background) m_window.draw(*m_background);
    bool goingToBoss = (m_levelManager.getLevelNumber() == TOTAL_LEVELS);
    std::string msg = goingToBoss ? "PREPARE FOR THE BOSS!"
        : "LEVEL " + std::to_string(m_levelManager.getLevelNumber()) + " COMPLETE!";
    m_window.draw(makeText(msg, 46, sf::Color::Yellow, {(float)WINDOW_WIDTH/2.f - 250.f, 270.f}));
    m_window.draw(makeText("Score: " + std::to_string(m_score), 28,
                            sf::Color::White, {(float)WINDOW_WIDTH/2.f - 80.f, 350.f}));
    m_window.draw(makeText("Press ENTER to continue...", 20,
                            sf::Color(180,180,180), {(float)WINDOW_WIDTH/2.f - 130.f, 410.f}));
}

void Game::drawBossIntro() {
    sf::RectangleShape overlay({(float)WINDOW_WIDTH, (float)WINDOW_HEIGHT});
    overlay.setFillColor(sf::Color(0,0,0,140));
    m_window.draw(overlay);
    m_window.draw(makeText("BOSS INCOMING!", 56, sf::Color(220,0,0),
                            {(float)WINDOW_WIDTH/2.f - 220.f, 270.f}));
    m_window.draw(makeText("Defeat the Zombie King to win!", 24,
                            sf::Color::White, {(float)WINDOW_WIDTH/2.f - 180.f, 350.f}));
}

void Game::drawGameOver() {
    if (m_background) m_window.draw(*m_background);
    m_window.draw(makeText("GAME OVER", 64, sf::Color(220,30,30),
                            {(float)WINDOW_WIDTH/2.f - 200.f, 210.f}));
    m_window.draw(makeText("Score: " + std::to_string(m_score), 30,
                            sf::Color::White, {(float)WINDOW_WIDTH/2.f - 80.f, 310.f}));
    m_window.draw(makeText("High Score: " + std::to_string(m_highScore), 24,
                            sf::Color::Yellow, {(float)WINDOW_WIDTH/2.f - 100.f, 355.f}));
    m_window.draw(makeText("ENTER: Main Menu    ESC: Exit", 20,
                            sf::Color(180,180,180), {(float)WINDOW_WIDTH/2.f - 160.f, 430.f}));
}

void Game::drawVictory() {
    if (m_background) m_window.draw(*m_background);
    m_window.draw(makeText("YOU WIN!", 72, sf::Color::Yellow,
                            {(float)WINDOW_WIDTH/2.f - 190.f, 190.f}));
    m_window.draw(makeText("The Zombie King is defeated!", 28,
                            sf::Color::White, {(float)WINDOW_WIDTH/2.f - 190.f, 290.f}));
    m_window.draw(makeText("Final Score: " + std::to_string(m_score), 30,
                            sf::Color::Cyan, {(float)WINDOW_WIDTH/2.f - 110.f, 350.f}));
    m_window.draw(makeText("High Score: " + std::to_string(m_highScore), 24,
                            sf::Color::Yellow, {(float)WINDOW_WIDTH/2.f - 100.f, 395.f}));
    m_window.draw(makeText("ENTER: Main Menu    ESC: Exit", 20,
                            sf::Color(180,180,180), {(float)WINDOW_WIDTH/2.f - 160.f, 470.f}));
}
