#include "SoundManager.h"
#include <iostream>

SoundManager& SoundManager::instance() {
    static SoundManager inst;
    return inst;
}

void SoundManager::loadSound(const std::string& name, const std::string& path) {
    sf::SoundBuffer buf;
    if (!buf.loadFromFile(path)) {
        std::cerr << "[SoundManager] Could not load sound: " << path << "\n";
        return;
    }
    m_buffers[name] = std::move(buf);
    auto snd = std::make_unique<sf::Sound>(m_buffers[name]);
    m_sounds[name] = std::move(snd);
}

void SoundManager::playSound(const std::string& name, float volume) {
    auto it = m_sounds.find(name);
    if (it == m_sounds.end()) return;
    it->second->setVolume(volume);
    it->second->play();
}

void SoundManager::playMusic(const std::string& path, bool loop, float volume) {
    // If the same track is already playing, do nothing
    if (m_currentMusicPath == path &&
        m_music.getStatus() == sf::Music::Status::Playing)
        return;

    if (!m_music.openFromFile(path)) {
        std::cerr << "[SoundManager] Could not open music: " << path << "\n";
        return;
    }
    m_currentMusicPath = path;
    m_music.setLooping(loop);
    m_music.setVolume(volume);
    m_music.play();
}

void SoundManager::stopMusic() {
    m_music.stop();
    m_currentMusicPath.clear();
}

void SoundManager::pauseMusic() {
    if (m_music.getStatus() == sf::Music::Status::Playing)
        m_music.pause();
}

void SoundManager::resumeMusic() {
    if (m_music.getStatus() == sf::Music::Status::Paused)
        m_music.play();
}

bool SoundManager::isMusicPlaying() const {
    return m_music.getStatus() == sf::Music::Status::Playing;
}
