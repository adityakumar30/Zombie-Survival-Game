#include "TextureManager.h"
#include <iostream>

TextureManager& TextureManager::instance() {
    static TextureManager inst;
    return inst;
}

sf::Texture& TextureManager::get(const std::string& path) {
    auto it = m_cache.find(path);
    if (it != m_cache.end()) return it->second;

    sf::Texture tex;
    if (!tex.loadFromFile(path)) {
        std::cerr << "[TextureManager] Could not load: " << path << " – using placeholder\n";
        m_cache[path] = makePlaceholder(sf::Color::Magenta);
    } else {
        m_cache[path] = std::move(tex);
    }
    return m_cache[path];
}

sf::Texture TextureManager::makePlaceholder(sf::Color color) {
    // SFML3: sf::Image constructor takes size + color
    sf::Image img(sf::Vector2u(32u, 32u), color);
    sf::Texture t;
    if (!t.loadFromImage(img)) {
        // fallback: return empty texture
    }
    return t;
}
